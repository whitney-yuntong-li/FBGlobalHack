<html>
<head>
<title>Thank You</title>
</head>
<body>
    Data Saved<br>
    <?php
        $wLi = $_POST['data'];
        print $_POST['message'];
        $f=fopen("SavedData.txt",'a');
        fwrite($f,$wLi));
        fclose($f)
    ?>
</body>
</html>