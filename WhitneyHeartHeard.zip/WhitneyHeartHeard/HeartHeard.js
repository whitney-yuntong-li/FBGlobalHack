


function SelectEmotion(elem) {
    document.getElementById('LandingPage').style.visibility='hidden';
    document.getElementById("feeling").style.visibility = "visible";
    document.getElementById('feelings').style.visibility='visible';
    // let feeling = elem.parentNode.id;
}




function StartExplore(){
    document.getElementById('LandingPage').style.visibility='hidden';
    document.getElementById('flowers').style.visibility='hidden';
    document.getElementById('emotionGroups').style.visibility='visible';
    document.getElementById('emotions').style.visibility='visible';
}

function response(r) {
    document.getElementById("show").innerHTML = r
}

/**
 * @return {number}
 */
function SelectNegative() {
    document.getElementById("feeling").style.visibility = "hidden";
    document.getElementById('feelings').style.visibility='hidden';
    document.getElementById('emotion').style.visibility='visible';
    document.getElementById('negative').style.visibility='visible';
    document.getElementById('NextSkip').style.visibility='visible';
    return document.getElementById("neg").selectedIndex;
}

/**
 * @return {number}
 */
function SelectPositive() {
    document.getElementById("feeling").style.visibility = "hidden";
    document.getElementById('feelings').style.visibility='hidden';
    document.getElementById('emotion').style.visibility='visible';
    document.getElementById('positive').style.visibility='visible';
    document.getElementById('NextSkip').style.visibility='visible';
    return document.getElementById("pos").selectedIndex;
}


function LandingPage() {
    document.getElementById("positive").style.visibility = "hidden";
    document.getElementById('negative').style.visibility='hidden';
    document.getElementById('NextSkip').style.visibility='hidden';
    document.getElementById('emotion').style.visibility='hidden';
    document.getElementById('emotions').style.visibility='hidden';
    document.getElementById('final').style.visibility='hidden';
    document.getElementById('LandingPage').style.visibility='visible';
    document.getElementById('back').style.visibility='hidden';
}

function AskSituation() {
    document.getElementById("positive").style.visibility = "hidden";
    document.getElementById('negative').style.visibility='hidden';
    document.getElementById('NextSkip').style.visibility='hidden';
    document.getElementById('emotion').style.visibility='hidden';
    document.getElementById('situation').style.visibility='visible';
    document.getElementById('details').style.visibility='visible';
    document.getElementById('important').style.visibility='visible';
    //situation = document.getElementById('situation1').value
    //response = document.getElementById('response1').value
}

function AskReflection(emotion) {
    document.getElementById('situation').style.visibility='hidden';
    document.getElementById('details').style.visibility='hidden';
    document.getElementById('important').style.visibility='hidden';
    if (emotion < 6){
        AskNegative()
    }
    else AskPositive()
}

function AskNegative(){
    document.getElementById('change').style.visibility='visible';
    document.getElementById('reflection').style.visibility='visible';
    document.getElementById('generator').style.visibility='visible';
}

function AskPositive(){
    document.getElementById('gratitude').style.visibility='visible';
    document.getElementById('thanks').style.visibility='visible';
    document.getElementById('generator').style.visibility='visible';
}

function GenerateFlower(){
    document.getElementById('gratitude').style.visibility='hidden';
    document.getElementById('thanks').style.visibility='hidden';
    document.getElementById('change').style.visibility='hidden';
    document.getElementById('reflection').style.visibility='hidden';
    document.getElementById('flowers').style.visibility='visible';
    document.getElementById('final').style.visibility='visible';
    document.getElementById('back').style.visibility='visible';
    if (x == 1){
        document.getElementById("flowers").src = "Flowers/anxious.png";
    }
    else if (x == 2){
        document.getElementById("flowers").src = "Flowers/angry.png";
    }
    else if (x == 3){
        document.getElementById("flowers").src = "Flowers/sad.png";
    }
    else if (x == 4){
        document.getElementById("flowers").src = "Flowers/ashamed.png";
    }
    else if (x == 5){
        document.getElementById("flowers").src = "Flowers/disgust.png";
    }
   else  if (x == 6){
        document.getElementById("flowers").src = "Flowers/happy.png";
    }
    else if (x == 7){
        document.getElementById("flowers").src = "Flowers/trusted.png";
    }
    else {
        document.getElementById("flowers").src = "Flowers/excited.png";
    }
    document.getElementById('generator').style.visibility='hidden';
}

class Trial {
    constructor(feeling, emotion, index, time, situation, response, reflection) {
        this.feeling = feeling;
        this.emotion = emotion;
        this.index = index;
        this.time = Date.now();
        this.situation = situation;
        this.response = response;
        this.reflection = reflection;
    }


    getDescription() {
        return "Flower: " + this.index +
            "\nFeeling: " + this.feeling +
            "\nEmotion: " + this.emotion +
            "\nIndex: " + this.index +
            "\nTime: " + this.time +
            "\nSituation: " + this.situation +
            "\nResponse: " + this.response +
            "\nSituation: " + this.situation;
    }

}
//    let record ={
//         time: Date(),
//         Emotion : emotion,
//     }
//     info.push(record);
//     document.getElementById('generator').style.visibility='hidden';
//     document.getElementById("info").innerHTML =
//         "Time:" + Date() + " Emotion: " + emotion + " Situation: " + situation + " Response: " + response +
//         " Reflection: " + reflection +
//         " Plan: " + plan + "<br />" ;
//     document.getElementById('info').style.visibility='visible';