package com.example.bjkim.helloworld;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Emotions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emotions);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    int count = 0;
    List<String> onList = new ArrayList<>();
    Map<String, Integer> emotionMap = new HashMap<String, Integer>() {{
        put("anxious", 1);
        put("scared", 1);
        put("overwhelmed", 1);
        put("angry", 2);
        put("annoyed", 2);
        put("sad", 3);
        put("hopeless", 3);
        put("worthless", 3);
        put("ashamed", 4);
        put("guilty", 4);
        put("disgusted", 5);
        put("empty", 5);
        put("bored", 5);
        put("happy", 6);
        put("surprised", 6);
        put("amazed", 6);
        put("trusted", 7);
        put("accepted", 7);
        put("grateful", 7);
        put("excited", 8);
        put("motivated", 8);
        put("proud", 8);
    }};

    public void onToggleClicked(View view) {
        // Is the toggle on?
        boolean on = ((ToggleButton) view).isChecked();
        if (on) {
            count++;
            onList.add(((Button)view).toString());
            }
        else {
            count--;
            onList.remove(((Button)view).toString());
        }
    }



    public void toSituation(View view){

        if (count > 3 || count == 0) {
            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
            builder1.setMessage("Please select 1 to 3 emotions!");
            builder1.setCancelable(true);
            builder1.setNegativeButton(
                    "Okay",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            AlertDialog alert11 = builder1.create();
            alert11.show();
        }
         else {
            Set<Integer> flowerSet = new HashSet<>();
            for (String item : onList) {
                flowerSet.add(emotionMap.get(item));
            }
        startActivity(new Intent(this, Situation.class));
        }}}
