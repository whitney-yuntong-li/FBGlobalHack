package com.example.bjkim.helloworld;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Flower extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flower);
        Emotions newEm = new Emotions();
        List<String> onList = newEm.onList;
        Set<Integer> flowerSet = new HashSet();
        List<String> ImList = new ArrayList<>();
        for (String item : onList) {
            flowerSet.add(newEm.emotionMap.get(item));
        }
        for (Integer item : flowerSet) {
            ImList.add(newEm.flowerMap.get(item));
        }




        for (int i = 0; i < ImList.size(); i++) {
            ImageView myImage = (ImageView) findViewById(R.id.flower1);
            if (!ImList.get(i).equals("angry")) {
                myImage.setBackgroundResource(R.drawable.excited);
            }
        }

    }





}
