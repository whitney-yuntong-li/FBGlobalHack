package com.example.bjkim.helloworld;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Emotions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emotions);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public int count = 0;
    public List<String> onList = new ArrayList<>();
    public List<View> onViewList = new ArrayList<>();

    public List<View> allList = new ArrayList<>();

    public Map<String, Integer> emotionMap = new HashMap<String, Integer>() {{
        put("anxious", 1);
        put("scared", 1);
        put("overwhelmed", 1);
        put("angry", 2);
        put("annoyed", 2);
        put("sad", 3);
        put("hopeless", 3);
        put("worthless", 3);
        put("ashamed", 4);
        put("guilty", 4);
        put("disgusted", 5);
        put("empty", 5);
        put("bored", 5);
        put("happy", 6);
        put("surprised", 6);
        put("amazed", 6);
        put("trusted", 7);
        put("accepted", 7);
        put("grateful", 7);
        put("excited", 8);
        put("motivated", 8);
        put("proud", 8);
    }};
    public Map<Integer, String> flowerMap = new HashMap<Integer, String>() {{
        put(1, "anxious");
        put(2, "angry");
        put(3, "sad");
        put(4, "ashamed");
        put(5, "disgust");
        put(6, "happy");
        put(7, "trusted");
        put(8, "excited");
    }};

    public Bitmap myBitmap;

    public Bitmap getBitmap() {
        return myBitmap;
    }

    public void onToggleClicked(View view) {
        // Is the toggle on?
        boolean on = ((ToggleButton) view).isChecked();

        if (on) {
            count++;
            onList.add(((Button)view).toString());
            onViewList.add(view);

            }
        else {
            count--;
            onList.remove(((Button)view).toString());
            onViewList.remove(view);

        }

    }

    Set<View> setList = new HashSet();

    public static Set<Integer> flowerSet = new HashSet();
    public static List<String> ImList = new ArrayList<>();
//    Bitmap stem = BitmapFactory.decodeResource(getResources(), R.drawable.stem);

    @SuppressLint("NewApi")
    public void revealFlowers(View view) {
        for (View views : onViewList) {
            setList.addAll(onViewList);
        }
//
//        for (View view : allList) {
//            view.setVisibility(View.INVISIBLE);
//        }
        for (View item : setList) {
            String flower = flowerMap.get(emotionMap.get(item.toString()));
            if (flower != null) {
                if (flower.equals("angry")) {
                    item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/angry.png"));
                } else {
                    if (flower.equals("sad")) {
                        item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/sad.png"));
                    } else {
                        if (flower.equals("anxious")) {
                            item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/anxious.png"));
                        } else {
                            if (flower.equals("disgust")) {
                                item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/disgust.png"));
                            } else {
                                if (flower.equals("excited")) {
                                    item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/excited.png"));
                                } else {
                                    if (flower.equals("happy")) {
                                        item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/happy.png"));
                                    } else {
                                        if (flower.equals("ashamed")) {
                                            item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/ashamed.png"));
                                        } else {
                                            if (flower.equals("trusted")) {
                                                item.setBackground(Drawable.createFromPath("C:/Users/bjkim/AndroidStudioProjects/HelloWorld/app/src/main/res/drawable/trusted.png"));
                                            } else {
                                                item.setVisibility(View.INVISIBLE);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            ;
        }
    }

//    public void toSituation(View view){
//
//        if (count > 3 || count == 0) {
//            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
//            builder1.setMessage("Please select 1 to 3 emotions!");
//            builder1.setCancelable(true);
//            builder1.setNegativeButton(
//                    "Okay",
//                    new DialogInterface.OnClickListener() {
//                        public void onClick(DialogInterface dialog, int id) {
//                            dialog.cancel();
//                        }
//                    });
//
//            AlertDialog alert11 = builder1.create();
//            alert11.show();
//        }
//         else {
//
//
//
//            startActivity(new Intent(this, Situation.class));
//        }}
 }
