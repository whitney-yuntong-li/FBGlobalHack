package com.example.bjkim.helloworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GrowFlower1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grow_flower1);
    }

    public Map<String, Integer> faceMap = new HashMap<String, Integer>() {
        {
            put("very_sad", 1);
            put("sad", 2);
            put("okay", 3);
            put("happy", 4);
            put("very_happy", 5);
        }};

    public void goToSituation(View view){

        startActivity(new Intent(this, Situation.class));
    }
}
