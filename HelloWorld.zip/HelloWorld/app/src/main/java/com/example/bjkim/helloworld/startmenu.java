package com.example.bjkim.helloworld;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;

import android.view.View;
import android.widget.TextView;


public class startmenu extends AppCompatActivity {

    private TextView mTextMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_startmenu);
        mTextMessage = (TextView) findViewById(R.id.title);
        mTextMessage.setGravity(Gravity.CENTER);
    }

    public void goToGrow(View view){
        startActivity(new Intent(this, GrowFlower1.class));
    }
//
//    public void goToGarden(View view){
//        startActivity(new Intent(this, Garden1.class));
//    }









}
